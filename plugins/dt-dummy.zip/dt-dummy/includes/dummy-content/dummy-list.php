<?php
$dummy_list = array(
	'the7' => array()
);

$path = 'business/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Business Demo',
		'screenshot' => array(
			'src' => 'demo-business.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/business/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'go_pricing',
			'recent-tweets-widget',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'creative/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Digital Agency Demo',
		'screenshot' => array(
			'src' => 'demo-creative.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/creative/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'go_pricing',
			'recent-tweets-widget',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'one-page/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Creative Agency Demo',
		'screenshot' => array(
			'src' => 'demo-one-page.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/one-page/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'go_pricing',
			'recent-tweets-widget',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'news/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'News Demo',
		'screenshot' => array(
			'src' => 'demo-news.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/news/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'go_pricing',
			'recent-tweets-widget',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'shop/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Shop Demo',
		'screenshot' => array(
			'src' => 'demo-shop.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/shop/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	),
);

$path = 'photo/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Photography Demo',
		'screenshot' => array(
			'src' => 'demo-photo.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/photo/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'go_pricing',
			'recent-tweets-widget',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'conference/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Conference Demo',
		'screenshot' => array(
			'src' => 'demo-conference.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/conference/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'beauty-studio/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Beauty Studio Demo',
		'screenshot' => array(
			'src' => 'demo-beauty-studio.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/beauty-studio/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'app/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'App Demo',
		'screenshot' => array(
			'src' => 'demo-app.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/app/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'marketing-agency/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Marketing Agency Demo',
		'screenshot' => array(
			'src' => 'demo-marketing-agency.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/marketing-agency/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'expedition/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Expedition Demo',
		'screenshot' => array(
			'src' => 'demo-expedition.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/expedition/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'product/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Product Demo',
		'screenshot' => array(
			'src' => 'demo-product.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/product/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'dance/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Dance School Demo',
		'screenshot' => array(
			'src' => 'demo-dance.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/dance/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'cv/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'CV Demo',
		'screenshot' => array(
			'src' => 'demo-cv.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/cv/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'coffee/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Coffee Demo',
		'screenshot' => array(
			'src' => 'demo-coffee.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/coffee/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'medical/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Medical Demo',
		'screenshot' => array(
			'src' => 'demo-medical.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/medical/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'law/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Law Demo',
		'screenshot' => array(
			'src' => 'demo-law.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/law/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'psy/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Psychology Demo',
		'screenshot' => array(
			'src' => 'demo-psy.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/psy/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'hosting/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Hosting Demo',
		'screenshot' => array(
			'src' => 'demo-hosting.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/hosting/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'construction/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Construction Demo',
		'screenshot' => array(
			'src' => 'demo-construction.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/construction/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
			'convertplug',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'digital-artist/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Digital Artist Demo',
		'screenshot' => array(
			'src' => 'demo-digital-artist.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/digital-artist/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'restaurant/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Restaurant Demo',
		'screenshot' => array(
			'src' => 'demo-restaurant.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/restaurant/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'web-master/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Web Master Demo',
		'screenshot' => array(
			'src' => 'demo-web-master.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/web-master/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '<p><strong>Обратите внимание, что все изображения защищены авторским правом были заменены заполнителем  изображения.</strong></p>',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
		),
	)
);

$path = 'dev-studio/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Seven Dev Demo',
		'screenshot' => array(
			'src' => 'demo-dev-studio.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/dev-studio/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'coming-soon-01/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Coming Soon Minimal Demo',
		'screenshot' => array(
			'src' => 'demo-coming-soon-01.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/coming-soon-01/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'coming-soon-02/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Coming Soon Revolution Demo',
		'screenshot' => array(
			'src' => 'demo-coming-soon-02.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/coming-soon-02/',
		'req_plugins' => array(
			'dt-the7-core',
			'revslider',
			'js_composer',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'business-one-page/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Business One Page Website Demo',
		'screenshot' => array(
			'src' => 'demo-business-one-page.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/business-one-page/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'personal-creative/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'The7 Personal Creative Website Demo',
		'screenshot' => array(
			'src' => 'personal-creative.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/personal-creative/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'revslider',
			'Ultimate_VC_Addons',
		),
		'top_content' => '',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$path = 'new-landing/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'The7 Landing Page',
		'screenshot' => array(
			'src' => 'demo-new-landing.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/demo/new-landing/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'Ultimate_VC_Addons',
			'revslider',
		),
		'top_content' => '',
		'bottom_content' => '',
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	)
);

$date = '.2016-04-14';
$path = 'main/';
$dummy_list['the7'][] =	array(
	'info' => array(
		'title' => 'Полный демо (слишком тяжелый, не рекомендуется)',
		'screenshot' => array(
			'src' => 'demo-main.jpg',
			'width' => '215',
			'height' => '161',
		),
		'link' => 'http://the7.dream-demo.com/',
		'req_plugins' => array(
			'dt-the7-core',
			'js_composer',
			'go_pricing',
			'recent-tweets-widget',
			'revslider',
		),
		'top_content' => '<p>
			<strong>Important!</strong> Этот демонстрационный пример огромен и адресуется продвинутым пользователям только! Много серверов будут бороться, импортируя это.<br>
 			Из-за огромного количества медиа-файлов и страниц, в случае крайней необходимости, Вы должны стереть и восстановить Вашу старую базу данных WordPress, чтобы заставить это работать снова.</p>
			<p><strong>Поэтому, пожалуйста, используйте "Компактный Демо" вместо этого - у него есть все страницы, в которых будет когда-либо нуждаться большинство пользователей.</strong></p>

 			Если вы столкнулись с проблемами импортируя демо-контент, пожалуйста, убедитесь, что ваш PHP.настройки ini не менее:<br>
			max_execution_time = 60<br>
			memory_limit = 256M<br>
			post_max_size = 64M<br>
			upload_max_filesize = 64M<br>
			Вы можете связаться с вашим хостингом для более подробной информации и помощи.
		</p>
		',
		'bottom_content' => ''
	),
	'site_meta' => $path . 'site-meta.json',
	'dummy_content' => array(
		'all' => array(
			'file_name' => $path . 'full-content.xml',
			'replace_attachments' => false,
		),
	),
);

unset( $date, $path );
